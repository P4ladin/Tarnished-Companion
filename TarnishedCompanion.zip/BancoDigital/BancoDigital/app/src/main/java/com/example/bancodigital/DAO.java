package com.example.bancodigital;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;


@Dao
public interface DAO {
   @Insert
   void InsereConta(ContaUsuario conta);

    @Query("SELECT * FROM ContaUsuario")
    List<ContaUsuario> getAll();

    @Query("SELECT * FROM ContaUsuario WHERE nomePersonagem=(:cpfcc) and senha=(:senhacc)")
    ContaUsuario Logar(String cpfcc, String senhacc);

@Delete
     void DeletarConta(ContaUsuario conta);
    // @Delete
    // void resetListaContas(List<ContaCorrente>conta);
    @Query("UPDATE ContaUsuario SET NomePersonagem = :SnomeP, NomeUsuario =:SnomeU, Email =:Semail, Senha =:Ssenha,   WHERE id = :Sid")
     void update(int Sid, String SnomeP,String SnomeU,String Semail,String Ssenha, String Sconta);
    //@Query("UPDATE ContaUsuario SET NomePersonagem = :SnomeP WHERE id = :Sid")
   // void update(int Sid, String SnomeP);
}
