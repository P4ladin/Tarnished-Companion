package com.example.bancodigital;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText login,senha;
    Button logar;
    TextView abrirConta, verContas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        abrirConta = findViewById(R.id.txtAbrirConta);
        verContas = findViewById(R.id.txtVerContas);
        login = findViewById(R.id.edtLoginLogin);
        senha = findViewById(R.id.edtSenhaLogin);
        logar = findViewById(R.id.btnLogarLogin);
        logar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Logar();
            }
        });
        abrirConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chamaTela();
            }
        });

        verContas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                VerConta();
            }
        });



    }

public void chamaTela()
{
    Intent telaCriaConta = new Intent(this, CriaConta.class);
    startActivity(telaCriaConta);
}

public void Logar()
{
    String c= login.getText().toString();
    String s =  senha.getText().toString();
    ContaCorrente cc = new ContaCorrente();
    if (login.getText().toString().isEmpty() && senha.getText().toString().isEmpty()){
        Toast.makeText(this, "LOGIN INVÁLIDO", Toast.LENGTH_LONG).show();
    }else if ( BaseDados.getInstance(this).getDAO().Logar(c,s)==null){
        Toast.makeText(this, "LOGIN INVÁLIDO", Toast.LENGTH_LONG).show();
    }else{

        Intent telaConta = new Intent(this, Conta.class);
        startActivity(telaConta);
    }
}
    public void VerConta(){
        Intent telaVerConta = new Intent(this, VerContas.class);
        startActivity(telaVerConta);
    }
}