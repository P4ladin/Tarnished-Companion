package com.example.bancodigital;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.RoomDatabase;
import androidx.room.Update;

import java.util.List;


@Dao
public interface DAO {
   @Insert
   void InsereConta(ContaCorrente conta);

    @Query("SELECT * FROM ContaCorrente")
    List<ContaCorrente> getAll();

    @Query("SELECT * FROM ContaCorrente WHERE cpf=(:cpfcc) and senha=(:senhacc)")
    ContaCorrente Logar(String cpfcc,String senhacc);

@Delete
     void DeletarConta(ContaCorrente conta);
    // @Delete
    // void resetListaContas(List<ContaCorrente>conta);
    @Query("UPDATE ContaCorrente SET Nome = :Snome, Cpf =:Scpf, Email =:Semail, Senha =:Ssenha, Conta=:Sconta   WHERE id = :Sid")
     void update(int Sid, String Snome,String Scpf,String Semail,String Ssenha, String Sconta);
    //@Query("UPDATE ContaCorrente SET Nome = :Snome WHERE id = :Sid")
   // void update(int Sid, String Snome);
}
